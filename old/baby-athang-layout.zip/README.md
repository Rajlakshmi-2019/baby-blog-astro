# Baby Athang Astro Layout

Astro starter project for a baby memory site with:

- Left banner image
- Gradient header with navigation pills
- Welcome section like the provided screenshot
- Placeholder pages for Photos, Milestones, Medical, Astrology, Schooling

## Setup

```bash
npm install
npm run dev
```

Put your banner image at:

- `public/photos/athang-banner.jpg`
