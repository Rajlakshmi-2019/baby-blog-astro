---
name: Jim Halpert
image: ../posts/images/coffee.jpg
---
